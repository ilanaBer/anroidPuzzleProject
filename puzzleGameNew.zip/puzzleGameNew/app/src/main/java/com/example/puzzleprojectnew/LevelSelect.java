package com.example.puzzleprojectnew;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LevelSelect extends AppCompatActivity {
    RadioGroup radioGroup;
    RadioButton lowLevel, mediumLevel,highLevel;
    Boolean low=false,medium=false,high=false;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.levelselect_layout);
        radioGroup=findViewById(R.id.radioSizes);

        updateLevel updateLevelListener = new updateLevel();
        lowLevel = findViewById(R.id.lowLevel);
        lowLevel.setOnCheckedChangeListener(updateLevelListener);

        mediumLevel = findViewById(R.id.mediumLevel);
        mediumLevel.setOnCheckedChangeListener(updateLevelListener);

        highLevel = findViewById(R.id.highLevel);
        highLevel.setOnCheckedChangeListener(updateLevelListener);
        Button continueLevel= findViewById(R.id.continue_btn);
        continueLevel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(LevelSelect.this, ImagesSelect.class);
                if(low){
                    String level="4";
                  intent.putExtra("level_select",level);
                    startActivity(intent);
                    //finish();
                }
                if(medium){
                    String level="5";
                    intent.putExtra("level_select",level);
                    startActivity(intent);
                    //finish();
                }
                if(high){
                    String level="6";
                    intent.putExtra("level_select",level);
                    startActivity(intent);
                  //  finish();
                }
            }
        });

    }
    private class updateLevel implements RadioButton.OnCheckedChangeListener{

        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            Toast.makeText(LevelSelect.this,"level selected",Toast.LENGTH_SHORT).show();
            levelChange();
        }
    }
    public void levelChange(){
        RadioButton lowLevel = findViewById(R.id.lowLevel);
       RadioButton mediumLevel = findViewById(R.id.mediumLevel);
       RadioButton highLevel = findViewById(R.id.highLevel);
       if(lowLevel.isChecked()){
           low=true;
       }
       if(mediumLevel.isChecked()){
           medium=true;
       }
       if ((highLevel.isChecked())){
           high=true;
       }
    }


}
