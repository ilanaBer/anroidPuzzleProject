package com.example.puzzleprojectnew;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class GameWon extends AppCompatActivity {
    TextView timeToShow;
    int numSeconds;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_won);
        //final String level =getIntent().getStringExtra("level_select");

        numSeconds=getIntent().getIntExtra("time", 1);
        timeToShow= findViewById(R.id.timeOfThepuzlle);
        timeToShow.setText(numSeconds+"");


    }
}