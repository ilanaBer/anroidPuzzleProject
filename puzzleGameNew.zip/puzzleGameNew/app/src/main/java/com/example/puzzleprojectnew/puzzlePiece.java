package com.example.puzzleprojectnew;


import android.content.Context;

public class puzzlePiece extends androidx.appcompat.widget.AppCompatImageView {
    public int x;
    public int y;
    public int pieceWidth;
    public int pieceHeight;
    public boolean canMove = true;

    public puzzlePiece(Context context) {
        super(context);
    }
}